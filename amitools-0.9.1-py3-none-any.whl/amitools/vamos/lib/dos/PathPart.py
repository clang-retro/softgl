"""helpers for path operations"""


def expand_progdir_path(ami_path, home_dir):
    """Expand '*' prefix (PROGDIR:) to the program's home directory.

    Args:
        ami_path: The Amiga path that may start with '*'
        home_dir: A lock object with ami_path attribute, or None

    Returns:
        The expanded path if ami_path starts with '*' and home_dir is set,
        otherwise returns ami_path unchanged.
    """
    if not str(ami_path).startswith("*") or home_dir is None:
        return ami_path

    home_path = home_dir.ami_path
    # Normalize base path for joining
    if home_path.endswith(":"):
        base_path = home_path
    elif home_path.endswith("/"):
        base_path = home_path[:-1]
    else:
        base_path = home_path

    rest = ami_path[1:]  # Remove the '*'
    if rest.startswith("/"):
        # '*/' means go up from home dir - join base with rest (which starts with /)
        return base_path + rest
    elif rest == "":
        # Just '*' means the home directory itself
        return home_path
    else:
        # '*name' means name relative to home dir
        if base_path.endswith(":"):
            return base_path + rest
        else:
            return base_path + "/" + rest


def file_part(path):
    pos = path.rfind("/")
    if pos != -1:
        pos += 1
    else:
        pos = path.find(":")
        if pos == -1:
            pos = 0
        else:
            pos += 1
    n = len(path)
    if pos >= n:
        pos = n
    return pos


def path_part(path):
    pos = path.rfind("/")
    if pos != -1:
        return pos
    else:
        pos = path.find(":")
        if pos == -1:
            pos = 0
        else:
            pos += 1
    n = len(path)
    if pos >= n:
        pos = n
    return pos


def split_name(name, separator, oldpos, size):
    """split off one part of a name at the given separator.

    Returns a tuple (next_pos, part). next_pos is the position after the
    separator to continue with the next part or -1 if the part was the
    last one. At most size - 1 characters are returned in part.
    """
    n = len(name)
    max_len = max(size - 1, 0)
    pos = oldpos
    part = []
    while pos < n and len(part) < max_len and ord(name[pos]) != separator:
        part.append(name[pos])
        pos += 1
    if pos < n and ord(name[pos]) == separator:
        return pos + 1, "".join(part)
    # a NUL separator matches the terminator at the end of the name
    if pos >= n and separator == 0:
        return pos + 1, "".join(part)
    return -1, "".join(part)


def add_part(dirname, filename, size):
    if len(dirname) == 0:
        return filename
    if len(filename) == 0:
        return dirname
    # does filename have a ':' ?
    pos = filename.find(":")
    if pos > 0:
        return filename
    elif pos == 0:
        # does dir have a ':'?
        dpos = dirname.find(":")
        if dpos >= 0:
            return dirname[0:dpos] + filename
        else:
            return filename
    else:
        # no colon in filenam
        if dirname[-1] in (":", "/"):
            return dirname + filename
        else:
            return dirname + "/" + filename
