from .slotarray import SlotArray
